

$(function() {

  $('.fas').click( function () {
    
    // reset other icons and descriptions
    $('.fas').removeClass('fa-minus').addClass('fa-plus')
    $('.item-info').slideUp()

    // slide the description of clicked icon
    $(this).parent().siblings().slideToggle()
    // toggle the class of the clicked icon
    $(this).toggleClass('fa-plus')
    $(this).toggleClass('fa-minus')
  } )

})