

fetch('https://jsonplaceholder.typicode.com/users')
.then( response => response.json() )
.then( data => {
  //console.log(data)
  data.forEach(user => {
    const card = document.createElement('div')
    card.classList.add('card')

    const template = `
    <div class="card-img"><img src="https://robohash.org/${user.username}?set=set4"></div>
    <div>Name: ${user.name}</div>
    <div>Username: ${user.username}</div>
    <div>City: ${user.address.city}</div>
    `

    card.innerHTML = template
    document.querySelector('.container').appendChild(card)
  })
  
})


$.getJSON('https://jsonplaceholder.typicode.com/users', data => {
  console.log(data)
})

$.ajax({
  url : 'https://jsonplaceholder.typicode.com/users'
}).done( data => {
  console.log(data)
})